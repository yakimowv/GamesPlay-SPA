import * as api from './api.js'


// export const login=api.login
// export const logout=api.logout
// export const register=api.register


export async function getallGames(){
    return api.get('/data/games?sortBy=_createdOn%20desc&distinct=category')
}
export async function getAllGamesForCatalog(){
    return api.get(`/data/games?sortBy=_createdOn%20desc`)
}

export async function getGameById(id){
    return api.get('/data/games/'+id)
}

// export async function getMyCars(userId){
//     return api.get(`/data/cars?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`)
// }

export async function createGame(game){
    return api.post('/data/games',game)
}

export async function editGame(id,game){
    return api.put('/data/games/'+id,game)
}
export async function delGame(id){
    return api.del('/data/games/'+id)
}
///Search

export async function getByGameId(gameId){
    return api.get(`/data/comments?where=gameId%3D%22${gameId}%22`)
}
export async function postCommend(comment){
    return api.post(`/data/comments`,comment)
}


//for likes //BONUS :)

// export async function likeBook(bookId){
//     return api.post('/data/likes',{
//         bookId
//     })
// }
// export async function getLikesByBookId(bookId){
//     return api.get(`/data/likes?where=bookId%3D%22${bookId}%22&distinct=_ownerId&count`)
// }
// export async function getMyLikeByBookId(bookId,userId){
//     return api.get(`/data/likes?where=bookId%3D%22${bookId}%22%20and%20_ownerId%3D%22${userId}%22&count`)
// }


// export async function searchSong(){
//     return api.get(`/data/albums?where=name%20LIKE%20%22${query}%22`)
// }