
import { html,nothing } from "../../node_modules/lit-html/lit-html.js";
import { getByGameId, getGameById } from "../api/data.js";

const formTemplaite =()=>html`
 <article class="create-comment">
                <label>Add new comment:</label>
                <form class="form">
                    <textarea name="comment" placeholder="Comment......"></textarea>
                    <input class="btn submit" type="submit" value="Add Comment">
                </form>
            </article>
`

export function commentFormView(ctx,gameId){
    if(ctx.userData){
        return formTemplaite()
    } else if (ctx.userData==null || userData.id==ctx.params._ownerId ){
        return nothing
    }
}