
import { html } from "../../node_modules/lit-html/lit-html.js";
import { getByGameId } from "../api/data.js";


const commnetsTemlayte=(comments)=>html`
         <div class="details-comments">
         <h2>Comments:</h2>

         ${comments.length==0 
            ?html`<p class="no-comment">No comments.</p>`
            :commentsList(comments)}
              
     </div>`
     

const commentsList=(comments)=>html`
         <ul>
            ${comments.map(commentsCard)}
        </ul>`

        
const commentsCard=(comment)=>html`
<li class="comment">
   <p>Content: ${comment.comment}</p>
</li>`


export async function commentsView(gameId){
    const comments =await getByGameId(gameId)
    return commnetsTemlayte(comments)
}